package com.urduvoice.tts

import android.content.Context
import org.json.JSONObject

/** Saved choices: selected voice style, last speech rate, and the user's pronunciation dictionary. */
object AppPrefs {
    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("urdu_voice", Context.MODE_PRIVATE)

    fun voice(ctx: Context): VoicePreset = VoicePresets.byId(p(ctx).getString("voice", null))
    fun setVoice(ctx: Context, id: String) = p(ctx).edit().putString("voice", id).apply()

    fun englishMode(ctx: Context): EnglishMode =
        try { EnglishMode.valueOf(p(ctx).getString("english", null) ?: "PHRASES") } catch (e: Exception) { EnglishMode.PHRASES }
    fun setEnglishMode(ctx: Context, m: EnglishMode) = p(ctx).edit().putString("english", m.name).apply()

    fun lastSpeed(ctx: Context): Float = p(ctx).getFloat("speed", 1f)
    fun setLastSpeed(ctx: Context, speed: Float) {
        if (lastSpeed(ctx) != speed) p(ctx).edit().putFloat("speed", speed).apply()
    }

    @Volatile private var dictCache: Map<String, String>? = null

    fun userDict(ctx: Context): Map<String, String> =
        dictCache ?: loadDict(ctx).also { dictCache = it }

    fun putWord(ctx: Context, word: String, sayAs: String) {
        val m = LinkedHashMap(userDict(ctx))
        m[word.trim()] = sayAs.trim()
        saveDict(ctx, m)
    }

    fun removeWord(ctx: Context, word: String) {
        val m = LinkedHashMap(userDict(ctx))
        m.remove(word)
        saveDict(ctx, m)
    }

    private fun loadDict(ctx: Context): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        try {
            val o = JSONObject(p(ctx).getString("dict", "{}") ?: "{}")
            for (k in o.keys()) m[k] = o.getString(k)
        } catch (_: Exception) { }
        return m
    }

    private fun saveDict(ctx: Context, m: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        p(ctx).edit().putString("dict", o.toString()).apply()
        dictCache = m
    }
}
