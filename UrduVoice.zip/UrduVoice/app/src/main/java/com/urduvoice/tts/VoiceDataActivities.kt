package com.urduvoice.tts

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech

/** Answers Android's "is the voice installed?" check. Voice ships inside the APK, so always yes. */
class CheckVoiceDataActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val result = Intent().apply {
            putStringArrayListExtra(TextToSpeech.Engine.EXTRA_AVAILABLE_VOICES, arrayListOf("urd-PAK"))
            putStringArrayListExtra(TextToSpeech.Engine.EXTRA_UNAVAILABLE_VOICES, arrayListOf())
        }
        setResult(TextToSpeech.Engine.CHECK_VOICE_DATA_PASS, result)
        finish()
    }
}

/** Sample sentence for "Listen to an example" in Android TTS settings. */
class GetSampleTextActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val result = Intent().putExtra(
            TextToSpeech.Engine.EXTRA_SAMPLE_TEXT,
            "یہ اردو آواز کی ایک مثال ہے۔"
        )
        setResult(TextToSpeech.LANG_AVAILABLE, result)
        finish()
    }
}
