package com.urduvoice.tts

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer

/**
 * Matcha-TTS (text -> mel) + Vocos (mel -> spectrum) + ISTFT (spectrum -> audio).
 * One shared instance for the whole app (test screen + system TTS service).
 */
class UrduTtsEngine private constructor(ctx: Context) {

    companion object {
        const val SAMPLE_RATE = 22050
        const val ACOUSTIC_MODEL = "matcha_tts.onnx"
        const val VOCODER_MODEL = "vocos-22khz-univ.onnx"
        const val VOCAB = "vocab.json"

        @Volatile private var instance: UrduTtsEngine? = null

        fun get(ctx: Context): UrduTtsEngine =
            instance ?: synchronized(this) {
                instance ?: UrduTtsEngine(ctx.applicationContext).also { instance = it }
            }

        fun isLoaded() = instance != null

        /** Float [-1,1] samples -> 16-bit little-endian PCM bytes. */
        fun toPcm16(wav: FloatArray): ByteArray {
            val out = ByteArray(wav.size * 2)
            for (i in wav.indices) {
                val v = (wav[i].coerceIn(-1f, 1f) * 32767f).toInt()
                out[2 * i] = (v and 0xff).toByte()
                out[2 * i + 1] = ((v shr 8) and 0xff).toByte()
            }
            return out
        }
    }

    data class Stats(val modelMs: Long, val vocoderMs: Long, val audioSec: Float)

    private val env = OrtEnvironment.getEnvironment()
    private val acoustic: OrtSession
    private val vocoder: OrtSession
    private val vocoderInput: String
    private val stoi: Map<Char, Long>
    private val spaceId: Long
    private val istft: Istft
    @Volatile var lastStats: Stats? = null
        private set

    init {
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(threads)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        acoustic = env.createSession(assetToFile(ctx, ACOUSTIC_MODEL).absolutePath, opts)
        vocoder = env.createSession(assetToFile(ctx, VOCODER_MODEL).absolutePath, opts)
        vocoderInput = vocoder.inputNames.first()

        val json = JSONObject(ctx.assets.open(VOCAB).bufferedReader(Charsets.UTF_8).use { it.readText() })
        val map = HashMap<Char, Long>()
        for (key in json.keys()) if (key.length == 1) map[key[0]] = json.getLong(key)
        stoi = map
        spaceId = map[' '] ?: 0L

        val meta = vocoder.metadata.customMetadata
        val nFft = meta["n_fft"]?.toIntOrNull() ?: 1024
        val hop = meta["hop_length"]?.toIntOrNull() ?: 256
        val win = meta["win_length"]?.toIntOrNull() ?: nFft
        istft = Istft(nFft, hop, win)
    }

    /** Character ids with a blank (0) before, between and after each character. */
    private fun encode(text: String): LongArray {
        val ids = LongArray(text.length * 2 + 1)
        var i = 1
        for (ch in text) {
            ids[i] = stoi[ch] ?: spaceId
            i += 2
        }
        return ids
    }

    /** text must already be normalized. speed 1.0 = normal. */
    @Synchronized
    fun synthesize(text: String, speed: Float = 1f, temperature: Float = 0.667f): FloatArray {
        if (text.isBlank()) return FloatArray(0)
        val t0 = System.nanoTime()

        val ids = encode(text)
        val mel: FloatArray
        val melShape: LongArray
        OnnxTensor.createTensor(env, LongBuffer.wrap(ids), longArrayOf(1, ids.size.toLong())).use { x ->
            OnnxTensor.createTensor(env, LongBuffer.wrap(longArrayOf(ids.size.toLong())), longArrayOf(1)).use { xLen ->
                OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArrayOf(temperature, 1f / speed)), longArrayOf(2)).use { scales ->
                    acoustic.run(mapOf("x" to x, "x_lengths" to xLen, "scales" to scales)).use { r ->
                        val t = r.get(0) as OnnxTensor
                        melShape = t.info.shape
                        val fb = t.floatBuffer
                        mel = FloatArray(fb.remaining()).also { fb.get(it) }
                    }
                }
            }
        }
        val t1 = System.nanoTime()

        val wav: FloatArray
        OnnxTensor.createTensor(env, FloatBuffer.wrap(mel), melShape).use { melIn ->
            vocoder.run(mapOf(vocoderInput to melIn)).use { r ->
                fun out(name: String, index: Int): OnnxTensor =
                    (r.get(name).orElse(null) ?: r.get(index)) as OnnxTensor
                val magT = out("mag", 0)
                val frames = magT.info.shape.last().toInt()
                val mag = magT.floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } }
                val xs = out("x", 1).floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } }
                val ys = out("y", 2).floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } }
                wav = istft.process(mag, xs, ys, frames)
            }
        }
        val t2 = System.nanoTime()

        lastStats = Stats((t1 - t0) / 1_000_000, (t2 - t1) / 1_000_000, wav.size / SAMPLE_RATE.toFloat())
        return wav
    }

    /** ONNX Runtime loads from a file path; copy the asset once (again after app updates). */
    private fun assetToFile(ctx: Context, name: String): File {
        val out = File(ctx.filesDir, name)
        val installed = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        if (!out.exists() || out.lastModified() < installed) {
            val tmp = File(ctx.filesDir, "$name.tmp")
            ctx.assets.open(name).use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
            tmp.renameTo(out)
        }
        return out
    }
}
