package com.urduvoice.tts

/**
 * Roman Urdu ("kya haal hai") -> Urdu script.
 * STRONG words are clearly Urdu; WEAK words are also English words ("main", "to", "is")
 * and are only treated as Urdu when the sentence is detected as Roman Urdu.
 */
object RomanUrdu {

    private val STRONG = mapOf(
        "hai" to "ہے", "hain" to "ہیں", "hun" to "ہوں", "hoon" to "ہوں", "tha" to "تھا", "thi" to "تھی",
        "kya" to "کیا", "kia" to "کیا", "kyun" to "کیوں", "kyon" to "کیوں", "kaise" to "کیسے",
        "kaisa" to "کیسا", "kaisi" to "کیسی", "kahan" to "کہاں", "kab" to "کب", "kaun" to "کون", "kon" to "کون",
        "kitna" to "کتنا", "kitne" to "کتنے", "kitni" to "کتنی", "aap" to "آپ", "ap" to "آپ", "tum" to "تم",
        "tu" to "تو", "mein" to "میں", "mai" to "میں", "hum" to "ہم", "wo" to "وہ", "woh" to "وہ",
        "ye" to "یہ", "yeh" to "یہ", "mera" to "میرا", "meri" to "میری", "mere" to "میرے", "tera" to "تیرا",
        "teri" to "تیری", "tere" to "تیرے", "apna" to "اپنا", "apni" to "اپنی", "apne" to "اپنے",
        "hamara" to "ہمارا", "hamari" to "ہماری", "tumhara" to "تمہارا", "tumhari" to "تمہاری",
        "uska" to "اس کا", "uski" to "اس کی", "uske" to "اس کے", "iska" to "اس کا", "iski" to "اس کی",
        "nahi" to "نہیں", "nahin" to "نہیں", "nai" to "نہیں", "haan" to "ہاں", "han" to "ہاں", "ji" to "جی",
        "jee" to "جی", "theek" to "ٹھیک", "thik" to "ٹھیک", "acha" to "اچھا", "achha" to "اچھا",
        "achi" to "اچھی", "ache" to "اچھے", "bura" to "برا", "shukriya" to "شکریہ", "meharbani" to "مہربانی",
        "salam" to "سلام", "assalam" to "السلام", "alaikum" to "علیکم", "walaikum" to "وعلیکم",
        "khuda" to "خدا", "hafiz" to "حافظ", "allah" to "اللہ", "inshallah" to "ان شاء اللہ",
        "mashallah" to "ماشاء اللہ", "subhanallah" to "سبحان اللہ", "alhamdulillah" to "الحمدللہ",
        "bhai" to "بھائی", "behan" to "بہن", "ami" to "امی", "ammi" to "امی", "abu" to "ابو", "abbu" to "ابو",
        "dost" to "دوست", "yaar" to "یار", "yar" to "یار", "jaan" to "جان", "ghar" to "گھر", "kaam" to "کام",
        "raat" to "رات", "subah" to "صبح", "sham" to "شام", "aaj" to "آج", "kal" to "کل", "abhi" to "ابھی",
        "phir" to "پھر", "fir" to "پھر", "jaldi" to "جلدی", "waqt" to "وقت", "paisa" to "پیسہ",
        "paise" to "پیسے", "khana" to "کھانا", "pani" to "پانی", "chai" to "چائے", "kar" to "کر",
        "karo" to "کرو", "karna" to "کرنا", "karen" to "کریں", "karein" to "کریں", "kiya" to "کیا",
        "raha" to "رہا", "rahi" to "رہی", "rahe" to "رہے", "gaya" to "گیا", "gayi" to "گئی", "gaye" to "گئے",
        "aya" to "آیا", "aaya" to "آیا", "aai" to "آئی", "aao" to "آؤ", "jao" to "جاؤ", "jana" to "جانا",
        "ana" to "آنا", "dena" to "دینا", "lena" to "لینا", "bolo" to "بولو", "batao" to "بتاؤ",
        "bata" to "بتا", "suno" to "سنو", "dekho" to "دیکھو", "dekh" to "دیکھ", "chalo" to "چلو",
        "ruko" to "رکو", "sab" to "سب", "kuch" to "کچھ", "koi" to "کوئی", "bohat" to "بہت",
        "bahut" to "بہت", "bht" to "بہت", "zyada" to "زیادہ", "aur" to "اور", "lekin" to "لیکن",
        "magar" to "مگر", "se" to "سے", "ko" to "کو", "ka" to "کا", "ki" to "کی", "ke" to "کے", "ne" to "نے",
        "bhi" to "بھی", "tak" to "تک", "wala" to "والا", "wali" to "والی", "wale" to "والے", "sath" to "ساتھ",
        "saath" to "ساتھ", "liye" to "لیے", "liya" to "لیا", "pata" to "پتا", "mujhe" to "مجھے",
        "mujh" to "مجھ", "tumhe" to "تمہیں", "tujhe" to "تجھے", "unhe" to "انہیں", "hume" to "ہمیں",
        "humein" to "ہمیں", "kisi" to "کسی", "agar" to "اگر", "sirf" to "صرف", "zaroor" to "ضرور",
        "zaroori" to "ضروری", "mushkil" to "مشکل", "asaan" to "آسان", "naya" to "نیا", "nayi" to "نئی",
        "purana" to "پرانا", "bara" to "بڑا", "bada" to "بڑا", "chota" to "چھوٹا", "larka" to "لڑکا",
        "larki" to "لڑکی", "baat" to "بات", "batein" to "باتیں", "sawal" to "سوال", "jawab" to "جواب",
        "khush" to "خوش", "udaas" to "اداس", "pyar" to "پیار", "mohabbat" to "محبت", "zindagi" to "زندگی",
        "duniya" to "دنیا", "mulk" to "ملک", "shehar" to "شہر", "dukan" to "دکان", "bazaar" to "بازار",
        "gari" to "گاڑی", "gaari" to "گاڑی", "raasta" to "راستہ", "sahi" to "صحیح", "galat" to "غلط",
        "haal" to "حال", "khair" to "خیر", "kharab" to "خراب", "kahin" to "کہیں", "yahan" to "یہاں",
        "wahan" to "وہاں", "andar" to "اندر", "bahar" to "باہر", "upar" to "اوپر", "neeche" to "نیچے",
        "pehle" to "پہلے", "baad" to "بعد", "hamesha" to "ہمیشہ", "kabhi" to "کبھی", "sakta" to "سکتا",
        "sakti" to "سکتی", "sakte" to "سکتے", "chahiye" to "چاہیے", "chahta" to "چاہتا", "chahti" to "چاہتی",
        "milna" to "ملنا", "mila" to "ملا", "mili" to "ملی", "hua" to "ہوا", "hui" to "ہوئی", "hue" to "ہوئے",
        "hoga" to "ہوگا", "hogi" to "ہوگی", "honge" to "ہوں گے", "jaega" to "جائے گا", "jayega" to "جائے گا",
        "karunga" to "کروں گا", "karungi" to "کروں گی", "dunga" to "دوں گا", "lunga" to "لوں گا",
        "beti" to "بیٹی", "amma" to "اماں", "nana" to "نانا", "dada" to "دادا"
    )

    private val WEAK = mapOf(
        "main" to "میں", "me" to "میں", "is" to "اس", "us" to "اس", "in" to "ان", "un" to "ان",
        "the" to "تھے", "na" to "نہ", "do" to "دو", "de" to "دے", "to" to "تو", "use" to "اسے",
        "par" to "پر", "kam" to "کم", "bas" to "بس", "lo" to "لو", "le" to "لے", "ho" to "ہو", "ya" to "یا",
        "bol" to "بول", "dil" to "دل", "din" to "دن", "der" to "دیر", "jo" to "جو", "tab" to "تب",
        "jab" to "جب", "kis" to "کس", "hi" to "ہی", "pe" to "پے", "mat" to "مت"
    )

    fun strongLookup(w: String): String? = STRONG[w]
    fun lookup(w: String): String? = STRONG[w] ?: WEAK[w]

    /** True if these Latin words look like Roman Urdu rather than English. */
    fun isRomanUrdu(words: List<String>): Boolean {
        if (words.isEmpty()) return false
        val strong = words.count { it in STRONG }
        return strong >= 2 || (strong == 1 && words.size <= 3)
    }

    private val RULES = listOf(
        "aa" to "ا", "ee" to "ی", "ii" to "ی", "oo" to "و", "uu" to "و", "ai" to "ے", "ay" to "ے",
        "au" to "و", "aw" to "و", "kh" to "خ", "gh" to "غ", "sh" to "ش", "ch" to "چ", "th" to "تھ",
        "ph" to "پھ", "bh" to "بھ", "dh" to "دھ", "jh" to "جھ", "zh" to "ژ", "ng" to "نگ"
    )
    private val CONS = mapOf(
        'b' to "ب", 'c' to "ک", 'd' to "د", 'f' to "ف", 'g' to "گ", 'h' to "ہ", 'j' to "ج", 'k' to "ک",
        'l' to "ل", 'm' to "م", 'n' to "ن", 'p' to "پ", 'q' to "ق", 'r' to "ر", 's' to "س", 't' to "ت",
        'v' to "و", 'w' to "و", 'x' to "کس", 'y' to "ی", 'z' to "ز"
    )

    private fun isVowel(c: Char) = c in "aeiou"

    fun phonetic(w0: String): String {
        val w = buildString { for (c in w0) if (isEmpty() || c != last() || isVowel(c)) append(c) }
        val sb = StringBuilder()
        var i = 0
        while (i < w.length) {
            val start = i == 0
            val rule = RULES.firstOrNull { w.startsWith(it.first, i) }
            if (rule != null) {
                when {
                    start && rule.first == "aa" -> sb.append("آ")
                    start && isVowel(rule.first[0]) -> sb.append("ا").append(rule.second)
                    else -> sb.append(rule.second)
                }
                i += rule.first.length
                continue
            }
            val c = w[i]
            val end = i == w.length - 1
            if (isVowel(c)) {
                val beforeFinalConsonant = i == w.length - 2 && !isVowel(w[i + 1])
                sb.append(
                    when (c) {
                        'a' -> if (start || end || beforeFinalConsonant) "ا" else ""
                        'e' -> if (start) "ای" else if (end) "ے" else "ی"
                        'i' -> if (start) "ا" else "ی"
                        'o' -> if (start) "او" else "و"
                        else -> if (start) "ا" else if (end) "و" else "" // u
                    }
                )
            } else {
                sb.append(CONS[c] ?: "")
            }
            i++
        }
        return sb.toString()
    }
}
