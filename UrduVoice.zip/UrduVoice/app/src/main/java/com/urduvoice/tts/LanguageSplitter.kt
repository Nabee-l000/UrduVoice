package com.urduvoice.tts

/** How English text is spoken. */
enum class EnglishMode(val label: String) {
    OFF("Urdu accent only (fastest)"),
    PHRASES("Real English for English phrases (recommended)"),
    ALL("Real English for every English word")
}

data class Segment(val text: String, val english: Boolean)

/**
 * Splits a sentence into Urdu parts and English parts.
 * - Pure English text ("Battery saver is on") -> English voice
 * - English phrases of 3+ words inside Urdu -> English voice
 * - 1-2 English words inside Urdu ("WhatsApp پر message") stay with the Urdu voice
 *   (Pakistani-style reading, no voice jump) unless mode = ALL
 * - Roman Urdu ("kya haal hai") is always Urdu
 */
object LanguageSplitter {
    private const val MIN_WORDS = 3
    private val ARABIC = Regex("[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")
    // An English stretch: starts with a Latin letter, runs through letters, digits, spaces and
    // common punctuation, and stops at Urdu letters or emoji.
    private val LATIN_SPAN = Regex("""[A-Za-z][A-Za-z0-9'’ .,:;!?%&@#/()+\-]*""")
    private val LATIN_WORD = Regex("[A-Za-z]+")

    private fun words(s: String) = LATIN_WORD.findAll(s).map { it.value.lowercase() }.toList()

    fun split(text: String, mode: EnglishMode): List<Segment> {
        if (mode == EnglishMode.OFF || text.isBlank()) return listOf(Segment(text, false))
        val all = words(text)
        if (all.isEmpty()) return listOf(Segment(text, false))
        val hasUrdu = ARABIC.containsMatchIn(text)
        if (!hasUrdu) return listOf(Segment(text, !RomanUrdu.isRomanUrdu(all)))

        val out = mutableListOf<Segment>()
        var pos = 0
        for (m in LATIN_SPAN.findAll(text)) {
            val span = m.value.trimEnd()
            val w = words(span)
            val english = !RomanUrdu.isRomanUrdu(w) && (mode == EnglishMode.ALL || w.size >= MIN_WORDS)
            if (!english) continue
            val start = m.range.first
            if (start > pos) add(out, text.substring(pos, start), false)
            add(out, span, true)
            pos = start + span.length
        }
        if (pos < text.length) add(out, text.substring(pos), false)
        return out.filter { it.text.isNotBlank() }.ifEmpty { listOf(Segment(text, false)) }
    }

    private fun add(out: MutableList<Segment>, t: String, english: Boolean) {
        if (out.isNotEmpty() && out.last().english == english) {
            out[out.size - 1] = Segment(out.last().text + t, english)
        } else {
            out += Segment(t, english)
        }
    }
}
