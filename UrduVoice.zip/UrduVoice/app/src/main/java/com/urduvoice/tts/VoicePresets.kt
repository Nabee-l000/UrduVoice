package com.urduvoice.tts

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow

/**
 * Voice styles made from the one Urdu voice: different pitch, pace and expressiveness.
 * (Truly different speakers need new recordings — see README.)
 */
data class VoicePreset(
    val id: String,
    val nameEn: String,
    val nameUr: String,
    val pitchSemitones: Float,
    val temperature: Float,   // lower = steadier, higher = more expressive
    val pace: Float           // multiplies the user's speed
) {
    val label get() = "$nameEn – $nameUr"
}

object VoicePresets {
    val ALL = listOf(
        VoicePreset("ur-pk-standard", "Standard", "معیاری", 0f, 0.667f, 1.0f),
        VoicePreset("ur-pk-deep", "Deep", "گہری", -3f, 0.6f, 0.95f),
        VoicePreset("ur-pk-bright", "Bright", "روشن", 2.5f, 0.667f, 1.03f),
        VoicePreset("ur-pk-calm", "Calm", "پرسکون", -1f, 0.35f, 0.9f),
        VoicePreset("ur-pk-lively", "Lively", "جاندار", 1f, 0.9f, 1.08f),
        VoicePreset("ur-pk-news", "Newsreader", "خبریں", -0.5f, 0.45f, 1.0f)
    )

    fun byId(id: String?): VoicePreset = ALL.firstOrNull { it.id == id } ?: ALL[0]
}

/** Pitch shift that keeps the same length: WSOLA time-stretch, then resample. */
object PitchShifter {
    private const val N = 1024
    private const val HS = N / 2
    private const val TOL = 256
    private val WIN = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / N)).toFloat() }

    fun shift(x: FloatArray, semitones: Float): FloatArray {
        if (semitones == 0f || x.size < N + 2 * TOL + HS) return x
        val r = 2.0.pow(semitones / 12.0)
        val st = timeStretch(x, r)
        val outLen = (st.size / r).toInt()
        val last = st.size - 1
        return FloatArray(outLen) { i ->
            val p = i * r
            val i0 = p.toInt()
            val f = (p - i0).toFloat()
            val a = st[min(i0, last)]
            val b = st[min(i0 + 1, last)]
            a + (b - a) * f
        }
    }

    private fun timeStretch(x: FloatArray, factor: Double): FloatArray {
        val ha = HS / factor
        val frames = ((x.size - N - 2 * TOL) / ha).toInt().coerceAtLeast(1)
        val out = FloatArray(frames * HS + N)
        val norm = FloatArray(out.size)
        var prev = 0
        for (k in 0 until frames) {
            val target = (k * ha).toInt() + TOL
            var best = target
            if (k > 0) {
                val natural = prev + HS
                var bestC = Double.NEGATIVE_INFINITY
                var d = -TOL
                while (d <= TOL) {
                    val c0 = target + d
                    if (c0 >= 0 && c0 + N <= x.size && natural + HS <= x.size) {
                        var c = 0.0
                        var j = 0
                        while (j < HS) { c += x[c0 + j] * x[natural + j]; j += 4 }
                        if (c > bestC) { bestC = c; best = c0 }
                    }
                    d += 2
                }
            }
            if (best + N > x.size) break
            val o = k * HS
            for (j in 0 until N) {
                out[o + j] += x[best + j] * WIN[j]
                norm[o + j] += WIN[j]
            }
            prev = best
        }
        for (i in out.indices) if (norm[i] > 1e-3f) out[i] /= norm[i]
        return out
    }
}
