package com.urduvoice.tts

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Inverse STFT matching torch.istft(center=True, hann window, normalized=False).
 * Turns the Vocos vocoder output (magnitude + phase as cos/sin) into a waveform.
 */
class Istft(private val nFft: Int, private val hop: Int, winLength: Int) {

    private val window = FloatArray(nFft)
    private val bins = nFft / 2 + 1

    init {
        require(nFft > 0 && (nFft and (nFft - 1)) == 0) { "n_fft must be a power of 2" }
        // Periodic Hann window of winLength, centred inside nFft (like torch)
        val off = (nFft - winLength) / 2
        for (n in 0 until winLength) {
            window[off + n] = (0.5 - 0.5 * cos(2.0 * PI * n / winLength)).toFloat()
        }
    }

    /** mag, xs, ys are [bins, frames] row-major (batch dim of 1 removed). */
    fun process(mag: FloatArray, xs: FloatArray, ys: FloatArray, frames: Int): FloatArray {
        if (frames <= 1) return FloatArray(0)
        val fullLen = nFft + hop * (frames - 1)
        val out = FloatArray(fullLen)
        val env = FloatArray(fullLen)
        val re = DoubleArray(nFft)
        val im = DoubleArray(nFft)

        for (t in 0 until frames) {
            for (k in 0 until bins) {
                val idx = k * frames + t
                val m = mag[idx]
                re[k] = (m * xs[idx]).toDouble()
                im[k] = (m * ys[idx]).toDouble()
            }
            im[0] = 0.0
            im[nFft / 2] = 0.0
            // Hermitian symmetry -> real output
            for (k in 1 until nFft / 2) {
                re[nFft - k] = re[k]
                im[nFft - k] = -im[k]
            }
            ifft(re, im)
            val start = t * hop
            for (n in 0 until nFft) {
                val w = window[n]
                out[start + n] += (re[n] / nFft).toFloat() * w
                env[start + n] += w * w
            }
        }

        val pad = nFft / 2
        val len = hop * (frames - 1)
        return FloatArray(len) { i ->
            val e = env[i + pad]
            if (e > 1e-11f) out[i + pad] / e else 0f
        }
    }

    /** In-place inverse FFT (unscaled). */
    private fun ifft(re: DoubleArray, im: DoubleArray) {
        val n = nFft
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = 2.0 * PI / len // positive sign = inverse
            val wRe = cos(ang)
            val wIm = sin(ang)
            val half = len / 2
            var i = 0
            while (i < n) {
                var cRe = 1.0
                var cIm = 0.0
                for (k in 0 until half) {
                    val a = i + k
                    val b = a + half
                    val vRe = re[b] * cRe - im[b] * cIm
                    val vIm = re[b] * cIm + im[b] * cRe
                    re[b] = re[a] - vRe
                    im[b] = im[a] - vIm
                    re[a] += vRe
                    im[a] += vIm
                    val nRe = cRe * wRe - cIm * wIm
                    cIm = cRe * wIm + cIm * wRe
                    cRe = nRe
                }
                i += len
            }
            len = len shl 1
        }
    }
}
