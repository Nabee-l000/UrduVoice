package com.urduvoice.tts

import android.content.Context
import android.util.Log

/** Speaks one sentence/clause: Urdu parts with the Urdu voice, English parts with the English voice. */
object MixedSpeaker {
    private const val TAG = "MixedSpeaker"

    /**
     * Streams audio for [raw] to [onAudio] segment by segment.
     * Returns a description of what each voice received (for the test screen).
     */
    fun speak(
        ctx: Context,
        raw: String,
        speed: Float,
        preset: VoicePreset,
        dict: Map<String, String>,
        mode: EnglishMode,
        isStopped: () -> Boolean,
        onAudio: (ByteArray) -> Unit
    ): String {
        val englishOk = mode != EnglishMode.OFF && EnglishEngine.available(ctx)
        val segments = LanguageSplitter.split(raw, if (englishOk) mode else EnglishMode.OFF)
        val urdu = UrduTtsEngine.get(ctx)
        val seen = StringBuilder()

        for (seg in segments) {
            if (isStopped()) break
            if (seg.english) {
                val pcm = try {
                    EnglishEngine.get(ctx).speakPcm(seg.text, speed)
                } catch (e: Throwable) {
                    Log.e(TAG, "English voice failed, using Urdu voice", e)
                    null
                }
                if (pcm != null) {
                    seen.append("[EN] ").append(EnglishEngine.clean(seg.text)).append("  ")
                    if (pcm.isNotEmpty()) onAudio(pcm)
                    continue
                }
            }
            val norm = UrduTextNormalizer.normalize(seg.text, dict)
            if (norm.isBlank()) continue
            seen.append("[UR] ").append(norm).append("  ")
            val pcm = urdu.speakPcm(norm, speed, preset)
            if (pcm.isNotEmpty()) onAudio(pcm)
        }
        return seen.toString().trim()
    }
}
