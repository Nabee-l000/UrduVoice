package com.urduvoice.tts

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** Test screen: type Urdu, hear it, see how fast it was. */
class MainActivity : Activity() {

    private val worker = Executors.newSingleThreadExecutor()
    private var track: AudioTrack? = null
    private var speed = 1.0f

    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var speakBtn: Button
    private lateinit var stats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        status = TextView(this).apply { text = "Loading voice…"; textSize = 16f }
        input = EditText(this).apply {
            setText("السلام علیکم! آپ کا آرڈر موصول ہو گیا ہے۔ بیٹری 45 فیصد ہے۔")
            textSize = 20f
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_RTL
        }
        val speedLabel = TextView(this).apply { text = "Speed: 1.0x" }
        val speedBar = SeekBar(this).apply {
            max = 25            // 0.5x .. 3.0x
            progress = 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    speed = 0.5f + p / 10f
                    speedLabel.text = "Speed: %.1fx".format(speed)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        speakBtn = Button(this).apply { text = "Speak / بولیں"; isEnabled = false; setOnClickListener { speak() } }
        stats = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 13f }
        val settingsBtn = Button(this).apply {
            text = "Set as phone TTS voice"
            setOnClickListener {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Open Settings → Accessibility → Text-to-speech", Toast.LENGTH_LONG).show() }
            }
        }
        val help = TextView(this).apply {
            text = "To use with TalkBack: tap the button above → Preferred engine → Urdu Voice. " +
                "Then set TalkBack's language to Urdu, or your phone language."
            textSize = 13f
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            listOf(status, input, speedLabel, speedBar, speakBtn, stats, settingsBtn, help).forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { addView(col) })

        worker.execute {
            val t0 = System.currentTimeMillis()
            try {
                val engine = UrduTtsEngine.get(this)
                engine.synthesize("سلام") // warm-up
                val ms = System.currentTimeMillis() - t0
                runOnUiThread { status.text = "Voice ready (loaded in $ms ms)"; speakBtn.isEnabled = true }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Failed to load voice: ${e.message}" }
            }
        }
    }

    private fun speak() {
        val text = input.text.toString()
        speakBtn.isEnabled = false
        worker.execute {
            val engine = UrduTtsEngine.get(this)
            val t0 = System.nanoTime()
            val chunks = mutableListOf<FloatArray>()
            var firstMs = -1L
            var modelMs = 0L
            var vocMs = 0L
            for (s in UrduTextNormalizer.splitSentences(text)) {
                val norm = UrduTextNormalizer.normalize(s)
                if (norm.isBlank()) continue
                chunks += engine.synthesize(norm, speed)
                engine.lastStats?.let { modelMs += it.modelMs; vocMs += it.vocoderMs }
                if (firstMs < 0) firstMs = (System.nanoTime() - t0) / 1_000_000
            }
            val totalMs = (System.nanoTime() - t0) / 1_000_000
            val wav = FloatArray(chunks.sumOf { it.size }).also { out ->
                var o = 0; for (c in chunks) { c.copyInto(out, o); o += c.size }
            }
            val audioSec = wav.size / UrduTtsEngine.SAMPLE_RATE.toFloat()
            val rtf = if (audioSec > 0) totalMs / 1000f / audioSec else 0f
            play(UrduTtsEngine.toPcm16(wav))
            runOnUiThread {
                stats.text = "First sentence ready: $firstMs ms\n" +
                    "Total: $totalMs ms (model $modelMs + vocoder $vocMs)\n" +
                    "Audio: %.2f s   RTF: %.2f %s".format(audioSec, rtf, if (rtf < 1) "✓ faster than real time" else "✗ too slow")
                speakBtn.isEnabled = true
            }
        }
    }

    private fun play(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        track?.release()
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(UrduTtsEngine.SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(pcm.size)
            .build()
            .also { it.write(pcm, 0, pcm.size); it.play() }
    }

    override fun onDestroy() {
        track?.release()
        worker.shutdown()
        super.onDestroy()
    }
}
