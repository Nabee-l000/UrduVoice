package com.urduvoice.tts

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.min

/** Test screen + settings: voice style, speed test, pronunciation dictionary. */
class MainActivity : Activity() {

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopFlag = false
    private var speed = 1.0f

    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var speakBtn: Button
    private lateinit var stats: TextView
    private lateinit var modelSees: TextView
    private lateinit var dictList: LinearLayout

    private val dp by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * dp).toInt()
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }

        val title = TextView(this).apply {
            text = "Urdu Voice  v$version"; textSize = 22f; setTypeface(typeface, Typeface.BOLD)
        }
        status = TextView(this).apply { text = "Loading voice…"; textSize = 15f }

        // --- Voice style ---
        val voiceLabel = header("Voice style (also used by TalkBack)")
        val presets = VoicePresets.ALL
        val voiceSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presets.map { it.label })
            setSelection(presets.indexOf(AppPrefs.voice(this@MainActivity)).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) =
                    AppPrefs.setVoice(this@MainActivity, presets[pos].id)
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }

        // --- English ---
        val englishLabel = header("English reading")
        val modes = EnglishMode.values()
        val englishAvailable = EnglishEngine.available(this)
        val englishSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, modes.map { it.label })
            setSelection(modes.indexOf(AppPrefs.englishMode(this@MainActivity)))
            isEnabled = englishAvailable
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) =
                    AppPrefs.setEnglishMode(this@MainActivity, modes[pos])
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        val englishNote = TextView(this).apply {
            textSize = 13f
            text = if (englishAvailable) "English voice: LJSpeech (Piper, public domain)"
                   else "English voice not included in this build"
        }

        // --- Test ---
        input = EditText(this).apply {
            setText("السلام علیکم! WhatsApp پر نیا message آیا ہے 😂 Battery saver is on. وقت 10:30 ہے۔ Kya haal hai?")
            textSize = 19f; minLines = 3
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_ANY_RTL
        }
        val speedLabel = TextView(this).apply { text = "Speed: 1.0x" }
        val speedBar = SeekBar(this).apply {
            max = 25; progress = 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    speed = 0.5f + p / 10f
                    speedLabel.text = "Speed: %.1fx".format(speed)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        speakBtn = Button(this).apply { text = "Speak / بولیں"; isEnabled = false; setOnClickListener { speak() } }
        val stopBtn = Button(this).apply { text = "Stop / روکیں"; setOnClickListener { stopSpeaking() } }
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(speakBtn, LinearLayout.LayoutParams(0, -2, 1f))
            addView(stopBtn, LinearLayout.LayoutParams(0, -2, 1f))
        }
        stats = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 13f }
        modelSees = TextView(this).apply { textSize = 15f; textDirection = View.TEXT_DIRECTION_RTL }

        // --- Pronunciation dictionary ---
        val dictHeader = header("My pronunciations / میرے تلفظ")
        val dictHelp = TextView(this).apply {
            text = "Word that sounds wrong → how to say it (in Urdu letters). Example: Daraz → دراز"
            textSize = 13f
        }
        val wordIn = EditText(this).apply { hint = "Word (e.g. Daraz)"; isSingleLine = true }
        val sayIn = EditText(this).apply { hint = "Say as (e.g. دراز)"; isSingleLine = true; textDirection = View.TEXT_DIRECTION_RTL }
        val addBtn = Button(this).apply {
            text = "Add / شامل کریں"
            setOnClickListener {
                val w = wordIn.text.toString().trim(); val s = sayIn.text.toString().trim()
                if (w.isEmpty() || s.isEmpty()) { toast("Fill both boxes"); return@setOnClickListener }
                AppPrefs.putWord(this@MainActivity, w, s)
                wordIn.setText(""); sayIn.setText("")
                refreshDict()
                toast("Saved: $w → $s")
            }
        }
        dictList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // --- System settings ---
        val settingsBtn = Button(this).apply {
            text = "Set as phone TTS voice"
            setOnClickListener {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                catch (e: Exception) { toast("Open Settings → Accessibility → Text-to-speech") }
            }
        }
        val help = TextView(this).apply {
            text = "For TalkBack: tap the button above → Preferred engine → Urdu Voice."
            textSize = 13f
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            listOf(
                title, status, voiceLabel, voiceSpinner, englishLabel, englishSpinner, englishNote, header("Test"), input, speedLabel, speedBar,
                btnRow, stats, modelSees, dictHeader, dictHelp, wordIn, sayIn, addBtn, dictList,
                header("Phone setup"), settingsBtn, help
            ).forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { addView(col) })
        refreshDict()

        worker.execute {
            val t0 = System.currentTimeMillis()
            try {
                val engine = UrduTtsEngine.get(this)
                engine.synthesize("سلام") // warm-up
                val ms = System.currentTimeMillis() - t0
                runOnUiThread { status.text = "Voice ready (loaded in $ms ms)"; speakBtn.isEnabled = true }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Failed to load voice: ${e.message}" }
            }
        }
    }

    private fun header(t: String) = TextView(this).apply {
        text = t; textSize = 17f; setTypeface(typeface, Typeface.BOLD)
        setPadding(0, (18 * dp).toInt(), 0, (4 * dp).toInt())
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun refreshDict() {
        dictList.removeAllViews()
        val dict = AppPrefs.userDict(this)
        if (dict.isEmpty()) {
            dictList.addView(TextView(this).apply { text = "(no words yet)"; textSize = 13f })
            return
        }
        for ((w, s) in dict) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = "$w → $s"; textSize = 16f }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Delete"
                contentDescription = "Delete $w"
                setOnClickListener { AppPrefs.removeWord(this@MainActivity, w); refreshDict() }
            })
            dictList.addView(row)
        }
    }

    private fun stopSpeaking() {
        stopFlag = true
        UrduTtsEngine.peek()?.cancel()
        track?.let { try { it.pause(); it.flush() } catch (_: Exception) { } }
    }

    private fun speak() {
        stopSpeaking()
        val text = input.text.toString()
        val preset = AppPrefs.voice(this)
        val dict = AppPrefs.userDict(this)
        speakBtn.isEnabled = false
        worker.execute {
            stopFlag = false
            val engine = UrduTtsEngine.get(this)
            engine.resetCancel()
            val mode = AppPrefs.englishMode(this)
            val chunks = UrduTextNormalizer.splitForSpeech(text)
            val seen = mutableListOf<String>()

            val at = openTrack()
            val t0 = System.nanoTime()
            var firstMs = -1L; var genMs = 0L; var samples = 0; var cachedHits = 0
            try {
                for (c in chunks) {
                    if (stopFlag) break
                    var mark = System.nanoTime()
                    val desc = MixedSpeaker.speak(this, c, speed, preset, dict, mode, { stopFlag }) { pcm ->
                        genMs += (System.nanoTime() - mark) / 1_000_000
                        if (firstMs < 0) firstMs = (System.nanoTime() - t0) / 1_000_000
                        samples += pcm.size / 2
                        var off = 0
                        while (off < pcm.size && !stopFlag) {    // stream: plays while the next part is generated
                            val n = min(8192, pcm.size - off)
                            at.write(pcm, off, n)
                            off += n
                        }
                        mark = System.nanoTime()
                    }
                    if (engine.lastStats?.cached == true) cachedHits++
                    seen += desc
                    val snapshot = "Model sees:\n" + seen.joinToString("\n")
                    runOnUiThread { modelSees.text = snapshot }
                }
            } catch (_: UrduTtsEngine.Cancelled) {
            } catch (e: Throwable) {
                runOnUiThread { stats.text = "Error: ${e.message}" }
            }
            val audioSec = samples / UrduTtsEngine.SAMPLE_RATE.toFloat()
            val rtf = if (audioSec > 0) genMs / 1000f / audioSec else 0f
            runOnUiThread {
                stats.text = "First audio after: $firstMs ms\n" +
                    "Generating: $genMs ms for %.2f s audio   RTF %.2f %s\n".format(audioSec, rtf, if (rtf < 1) "✓" else "✗ slow") +
                    "Voice: ${preset.label}   (instant from cache: $cachedHits/${chunks.size})"
                speakBtn.isEnabled = true
            }
        }
    }

    private fun openTrack(): AudioTrack {
        track?.let { try { it.release() } catch (_: Exception) { } }
        val minBuf = AudioTrack.getMinBufferSize(
            UrduTtsEngine.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(UrduTtsEngine.SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(maxOf(minBuf * 4, 32768))
            .build()
            .also { it.play(); track = it }
    }

    override fun onDestroy() {
        stopSpeaking()
        track?.release()
        worker.shutdown()
        super.onDestroy()
    }
}
