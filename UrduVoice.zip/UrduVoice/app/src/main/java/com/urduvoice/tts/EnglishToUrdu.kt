package com.urduvoice.tts

/**
 * The voice was trained on Urdu script only, so raw English letters come out as gibberish.
 * This rewrites English words in Urdu script (the way Pakistanis say them):
 *   1) dictionary of common phone / app words
 *   2) short ALL-CAPS words (USB, PDF) are spelled as letter names
 *   3) everything else goes through simple phonetic rules
 */
object EnglishToUrdu {

    private val DICT = mapOf(
        "ok" to "اوکے", "okay" to "اوکے", "wifi" to "وائی فائی", "bluetooth" to "بلوٹوتھ",
        "whatsapp" to "واٹس ایپ", "facebook" to "فیس بک", "youtube" to "یوٹیوب", "google" to "گوگل",
        "instagram" to "انسٹاگرام", "tiktok" to "ٹک ٹاک", "android" to "اینڈرائیڈ", "chrome" to "کروم",
        "app" to "ایپ", "apps" to "ایپس", "settings" to "سیٹنگز", "setting" to "سیٹنگ",
        "message" to "میسج", "messages" to "میسجز", "call" to "کال", "calls" to "کالز",
        "phone" to "فون", "mobile" to "موبائل", "camera" to "کیمرہ", "photo" to "فوٹو", "photos" to "فوٹوز",
        "video" to "ویڈیو", "videos" to "ویڈیوز", "gallery" to "گیلری", "battery" to "بیٹری",
        "charging" to "چارجنگ", "screen" to "سکرین", "home" to "ہوم", "back" to "بیک", "menu" to "مینیو",
        "search" to "سرچ", "button" to "بٹن", "double" to "ڈبل", "tap" to "ٹیپ", "click" to "کلک",
        "open" to "اوپن", "close" to "کلوز", "cancel" to "کینسل", "delete" to "ڈیلیٹ", "send" to "سینڈ",
        "share" to "شیئر", "save" to "سیو", "edit" to "ایڈٹ", "copy" to "کاپی", "paste" to "پیسٹ",
        "download" to "ڈاؤن لوڈ", "upload" to "اپ لوڈ", "internet" to "انٹرنیٹ", "data" to "ڈیٹا",
        "online" to "آن لائن", "offline" to "آف لائن", "on" to "آن", "off" to "آف", "email" to "ای میل",
        "browser" to "براؤزر", "link" to "لنک", "notification" to "نوٹیفکیشن",
        "notifications" to "نوٹیفکیشنز", "volume" to "والیوم", "music" to "میوزک", "play" to "پلے",
        "pause" to "پاز", "stop" to "سٹاپ", "next" to "نیکسٹ", "previous" to "پریویس", "file" to "فائل",
        "files" to "فائلز", "folder" to "فولڈر", "password" to "پاس ورڈ", "account" to "اکاؤنٹ",
        "login" to "لاگ ان", "logout" to "لاگ آؤٹ", "sign" to "سائن", "in" to "ان", "out" to "آؤٹ",
        "update" to "اپڈیٹ", "new" to "نیو", "chat" to "چیٹ", "chats" to "چیٹس", "status" to "سٹیٹس",
        "contact" to "کانٹیکٹ", "contacts" to "کانٹیکٹس", "keyboard" to "کی بورڈ", "talkback" to "ٹاک بیک",
        "mode" to "موڈ", "airplane" to "ایئرپلین", "location" to "لوکیشن", "clock" to "کلاک",
        "alarm" to "الارم", "time" to "ٹائم", "the" to "دی", "and" to "اینڈ", "is" to "از", "to" to "ٹو",
        "of" to "آف", "you" to "یو", "your" to "یور", "hello" to "ہیلو", "hi" to "ہائے", "yes" to "یس",
        "no" to "نو", "please" to "پلیز", "thanks" to "تھینکس", "thank" to "تھینک", "sorry" to "سوری",
        "i" to "آئی", "a" to "اے", "am" to "ایم", "pm" to "پی ایم", "user" to "یوزر", "users" to "یوزرز",
        "voice" to "وائس", "text" to "ٹیکسٹ", "speech" to "سپیچ", "list" to "لسٹ", "item" to "آئٹم",
        "items" to "آئٹمز", "page" to "پیج", "tab" to "ٹیب", "window" to "ونڈو", "free" to "فری",
        "storage" to "سٹوریج", "memory" to "میموری", "sim" to "سم", "network" to "نیٹ ورک",
        "signal" to "سگنل", "speaker" to "سپیکر", "microphone" to "مائیکروفون", "mic" to "مائیک",
        "sound" to "ساؤنڈ", "ringtone" to "رنگ ٹون", "silent" to "سائلنٹ", "vibrate" to "وائبریٹ",
        "brightness" to "برائٹنس", "dark" to "ڈارک", "light" to "لائٹ", "theme" to "تھیم",
        "language" to "لینگویج", "english" to "انگلش", "urdu" to "اردو", "pakistan" to "پاکستان",
        "map" to "میپ", "maps" to "میپس", "play store" to "پلے سٹور", "store" to "سٹور",
        "install" to "انسٹال", "uninstall" to "ان انسٹال", "allow" to "الاؤ", "deny" to "ڈینائی",
        "done" to "ڈن", "skip" to "سکپ", "continue" to "کنٹینیو", "submit" to "سبمٹ", "more" to "مور",
        "options" to "آپشنز", "option" to "آپشن", "unread" to "ان ریڈ", "read" to "ریڈ",
        "selected" to "سلیکٹڈ", "select" to "سلیکٹ", "checked" to "چیکڈ", "not" to "ناٹ",
        "enabled" to "اینیبلڈ", "disabled" to "ڈس ایبلڈ", "missed" to "مسڈ", "today" to "ٹوڈے",
        "yesterday" to "یسٹرڈے", "group" to "گروپ", "admin" to "ایڈمن", "price" to "پرائس",
        "gold" to "گولڈ", "market" to "مارکیٹ", "buy" to "بائے", "sell" to "سیل",
        // --- v0.3 additions: everyday, UI, apps, brands ---
        "accept" to "ایکسیپٹ", "add" to "ایڈ", "address" to "ایڈریس", "again" to "اگین", "all" to "آل",
        "about" to "اباؤٹ", "after" to "آفٹر", "also" to "آلسو", "apple" to "ایپل", "april" to "اپریل",
        "august" to "اگست", "auto" to "آٹو", "available" to "اویلیبل", "bank" to "بینک", "before" to "بیفور",
        "best" to "بیسٹ", "block" to "بلاک", "blocked" to "بلاکڈ", "book" to "بک", "box" to "باکس",
        "business" to "بزنس", "but" to "بٹ", "by" to "بائے", "calendar" to "کیلنڈر", "can" to "کین",
        "card" to "کارڈ", "change" to "چینج", "check" to "چیک", "city" to "سٹی", "clear" to "کلیئر",
        "code" to "کوڈ", "color" to "کلر", "colour" to "کلر", "comment" to "کمنٹ", "company" to "کمپنی",
        "computer" to "کمپیوٹر", "confirm" to "کنفرم", "connect" to "کنیکٹ", "connected" to "کنیکٹڈ",
        "connection" to "کنکشن", "cool" to "کول", "cricket" to "کرکٹ", "current" to "کرنٹ",
        "customer" to "کسٹمر", "date" to "ڈیٹ", "day" to "ڈے", "december" to "دسمبر", "default" to "ڈیفالٹ",
        "device" to "ڈیوائس", "dialog" to "ڈائیلاگ", "display" to "ڈسپلے", "do" to "ڈو",
        "document" to "ڈاکومنٹ", "down" to "ڈاؤن", "drive" to "ڈرائیو", "easy" to "ایزی", "enter" to "انٹر",
        "error" to "ایرر", "exit" to "ایگزٹ", "family" to "فیملی", "february" to "فروری",
        "feedback" to "فیڈ بیک", "find" to "فائنڈ", "finish" to "فنش", "for" to "فار", "forward" to "فارورڈ",
        "friend" to "فرینڈ", "friends" to "فرینڈز", "from" to "فرام", "full" to "فل", "game" to "گیم",
        "games" to "گیمز", "get" to "گیٹ", "go" to "گو", "good" to "گڈ", "great" to "گریٹ", "guest" to "گیسٹ",
        "have" to "ہیو", "has" to "ہیز", "help" to "ہیلپ", "here" to "ہیئر", "hide" to "ہائیڈ",
        "history" to "ہسٹری", "hour" to "آور", "hours" to "آورز", "how" to "ہاؤ", "icon" to "آئیکن",
        "image" to "امیج", "important" to "امپورٹنٹ", "info" to "انفو", "information" to "انفارمیشن",
        "invite" to "انوائٹ", "it" to "اٹ", "january" to "جنوری", "job" to "جاب", "join" to "جوائن",
        "july" to "جولائی", "june" to "جون", "just" to "جسٹ", "keep" to "کیپ", "key" to "کی", "know" to "نو",
        "laptop" to "لیپ ٹاپ", "last" to "لاسٹ", "later" to "لیٹر", "learn" to "لرن", "left" to "لیفٹ",
        "like" to "لائک", "live" to "لائیو", "load" to "لوڈ", "loading" to "لوڈنگ", "lock" to "لاک",
        "love" to "لو", "low" to "لو", "mail" to "میل", "main" to "مین", "manage" to "مینیج",
        "march" to "مارچ", "may" to "مے", "me" to "می", "media" to "میڈیا", "meeting" to "میٹنگ",
        "minute" to "منٹ", "minutes" to "منٹس", "money" to "منی", "month" to "منتھ", "morning" to "مارننگ",
        "mute" to "میوٹ", "my" to "مائی", "name" to "نیم", "navigate" to "نیویگیٹ", "navigation" to "نیویگیشن",
        "need" to "نیڈ", "news" to "نیوز", "night" to "نائٹ", "note" to "نوٹ", "notes" to "نوٹس",
        "november" to "نومبر", "now" to "ناؤ", "number" to "نمبر", "october" to "اکتوبر", "office" to "آفس",
        "one" to "ون", "only" to "اونلی", "or" to "آر", "order" to "آرڈر", "other" to "ادر", "over" to "اوور",
        "payment" to "پیمنٹ", "pay" to "پے", "people" to "پیپل", "permission" to "پرمیشن",
        "picture" to "پکچر", "pin" to "پن", "plan" to "پلان", "player" to "پلیئر", "plus" to "پلس",
        "point" to "پوائنٹ", "post" to "پوسٹ", "power" to "پاور", "press" to "پریس", "print" to "پرنٹ",
        "privacy" to "پرائیویسی", "profile" to "پروفائل", "quick" to "کوئیک", "recent" to "ریسنٹ",
        "record" to "ریکارڈ", "recording" to "ریکارڈنگ", "refresh" to "ریفریش", "remove" to "ریموو",
        "reply" to "ریپلائی", "report" to "رپورٹ", "reset" to "ری سیٹ", "restart" to "ری سٹارٹ",
        "right" to "رائٹ", "ring" to "رنگ", "room" to "روم", "run" to "رن", "scan" to "سکین",
        "school" to "سکول", "scroll" to "سکرول", "second" to "سیکنڈ", "seconds" to "سیکنڈز",
        "security" to "سیکیورٹی", "see" to "سی", "seen" to "سین", "september" to "ستمبر", "server" to "سرور",
        "service" to "سروس", "show" to "شو", "shop" to "شاپ", "shopping" to "شاپنگ", "size" to "سائز",
        "slide" to "سلائیڈ", "slow" to "سلو", "smart" to "سمارٹ", "so" to "سو", "social" to "سوشل",
        "song" to "سانگ", "speed" to "سپیڈ", "start" to "سٹارٹ", "sticker" to "سٹیکر", "story" to "سٹوری",
        "success" to "سکسیس", "support" to "سپورٹ", "swipe" to "سوائپ", "switch" to "سوئچ",
        "system" to "سسٹم", "team" to "ٹیم", "test" to "ٹیسٹ", "that" to "دیٹ", "this" to "دس",
        "ticket" to "ٹکٹ", "timer" to "ٹائمر", "title" to "ٹائٹل", "tomorrow" to "ٹومارو", "tools" to "ٹولز",
        "top" to "ٹاپ", "touch" to "ٹچ", "translate" to "ٹرانسلیٹ", "try" to "ٹرائی", "turn" to "ٹرن",
        "type" to "ٹائپ", "unlock" to "ان لاک", "up" to "اپ", "use" to "یوز", "username" to "یوزر نیم",
        "view" to "ویو", "visit" to "وزٹ", "wait" to "ویٹ", "wallet" to "والٹ", "want" to "وانٹ",
        "was" to "واز", "watch" to "واچ", "we" to "وی", "web" to "ویب", "website" to "ویب سائٹ",
        "week" to "ویک", "welcome" to "ویلکم", "what" to "واٹ", "when" to "وین", "where" to "ویئر",
        "which" to "وچ", "who" to "ہو", "why" to "وائے", "will" to "ول", "with" to "ود", "work" to "ورک",
        "world" to "ورلڈ", "write" to "رائٹ", "year" to "ایئر", "zoom" to "زوم", "jazz" to "جاز",
        "telenor" to "ٹیلی نار", "zong" to "زونگ", "ufone" to "یوفون", "easypaisa" to "ایزی پیسہ",
        "jazzcash" to "جاز کیش", "daraz" to "دراز", "foodpanda" to "فوڈ پانڈا", "careem" to "کریم",
        "uber" to "اوبر", "gmail" to "جی میل", "twitter" to "ٹویٹر", "snapchat" to "سنیپ چیٹ",
        "telegram" to "ٹیلی گرام", "messenger" to "میسنجر", "spotify" to "سپاٹیفائی", "netflix" to "نیٹ فلکس",
        "samsung" to "سام سنگ", "xiaomi" to "شیاؤمی", "oppo" to "اوپو", "vivo" to "ویوو",
        "infinix" to "انفینکس", "tecno" to "ٹیکنو", "iphone" to "آئی فون", "chatgpt" to "چیٹ جی پی ٹی",
        "claude" to "کلاڈ", "zoom" to "زوم", "excel" to "ایکسل", "word" to "ورڈ", "pdf" to "پی ڈی ایف", "at" to "ایٹ", "recharge" to "ریچارج",
        "balance" to "بیلنس", "package" to "پیکج", "bundle" to "بنڈل", "sms" to "ایس ایم ایس", "load" to "لوڈ",
        "mb" to "ایم بی", "gb" to "جی بی", "minutes" to "منٹس", "offer" to "آفر", "sale" to "سیل", "delivery" to "ڈیلیوری",
        "rider" to "رائیڈر", "booking" to "بکنگ", "ride" to "رائیڈ", "location" to "لوکیشن", "share" to "شیئر"
    )

    private val LETTERS = mapOf(
        'a' to "اے", 'b' to "بی", 'c' to "سی", 'd' to "ڈی", 'e' to "ای", 'f' to "ایف", 'g' to "جی",
        'h' to "ایچ", 'i' to "آئی", 'j' to "جے", 'k' to "کے", 'l' to "ایل", 'm' to "ایم", 'n' to "این",
        'o' to "او", 'p' to "پی", 'q' to "کیو", 'r' to "آر", 's' to "ایس", 't' to "ٹی", 'u' to "یو",
        'v' to "وی", 'w' to "ڈبلیو", 'x' to "ایکس", 'y' to "وائی", 'z' to "زیڈ"
    )

    // Longest patterns first
    private val RULES = listOf(
        "tion" to "شن", "sion" to "ژن", "ture" to "چر", "ight" to "ائٹ", "igh" to "ائی",
        "sch" to "سک", "tch" to "چ", "dge" to "ج", "ough" to "او", "oo" to "و", "ee" to "ی",
        "ea" to "ی", "ai" to "ے", "ay" to "ے", "ey" to "ے", "oa" to "و", "ow" to "او", "ou" to "او",
        "oy" to "وائے", "oi" to "وائے", "au" to "ا", "aw" to "ا", "sh" to "ش", "ch" to "چ",
        "th" to "تھ", "ph" to "ف", "gh" to "گ", "wh" to "و", "ck" to "ک", "qu" to "کو",
        "ng" to "نگ", "kh" to "خ"
    )

    private val CONSONANTS = mapOf(
        'b' to "ب", 'd' to "ڈ", 'f' to "ف", 'h' to "ہ", 'j' to "ج", 'k' to "ک", 'l' to "ل",
        'm' to "م", 'n' to "ن", 'p' to "پ", 'q' to "ک", 'r' to "ر", 's' to "س", 't' to "ٹ",
        'v' to "و", 'w' to "و", 'x' to "کس", 'z' to "ز"
    )

    private val WORD = Regex("""[A-Za-z]+(?:['’][A-Za-z]+)?""")

    fun convert(text: String): String {
        // Join common split forms first
        var s = text.replace(Regex("""(?i)\bwi[\s-]?fi\b"""), "wifi")
            .replace(Regex("""(?i)\bplay\s+store\b"""), "play store")
        s = s.replace(Regex("""(?i)\bplay store\b"""), " پلے سٹور ")
        val latinWords = WORD.findAll(s).map { it.value.lowercase() }.toList()
        val roman = RomanUrdu.isRomanUrdu(latinWords)
        return WORD.replace(s) { m -> " " + word(m.value, roman) + " " }
    }

    private fun word(raw: String, roman: Boolean): String {
        val w = raw.replace("'", "").replace("’", "")
        val lower = w.lowercase()
        // Roman Urdu sentence: Urdu meanings win ("main" = میں). Otherwise only clear Urdu words.
        (if (roman) RomanUrdu.lookup(lower) else RomanUrdu.strongLookup(lower))?.let { return it }
        DICT[lower]?.let { return it }
        if (roman && !(w.length in 2..5 && w.all { it.isUpperCase() })) return RomanUrdu.phonetic(lower)
        // Acronyms: USB, PDF, SMS
        if (w.length in 2..5 && w.all { it.isUpperCase() }) {
            return w.lowercase().map { LETTERS[it] ?: "" }.joinToString(" ")
        }
        if (w.length == 1) return LETTERS[lower[0]] ?: ""
        // Plural of a dictionary word: "buttons" -> بٹنز
        if (lower.endsWith("s") && DICT.containsKey(lower.dropLast(1))) return DICT[lower.dropLast(1)] + "ز"
        return phonetic(lower)
    }

    private fun isVowel(c: Char) = c in "aeiou"

    private fun phonetic(w0: String): String {
        var w = w0
        when {
            w.endsWith("ture") -> {}                                   // picture -> پکچر
            w.length > 3 && w.endsWith("ge") -> w = w.dropLast(2) + "j" // message -> میسج
            w.length > 3 && w.endsWith("ce") -> w = w.dropLast(2) + "s" // service -> سروس
            // Silent final e (home, phone) — keep for very short words
            w.length > 3 && w.endsWith("e") && !isVowel(w[w.length - 2]) -> w = w.dropLast(1)
        }
        if (w.length > 3 && w.endsWith("er")) w = w.dropLast(2) + "r"   // computer -> کمپیوٹر
        // Collapse doubled consonants (settings -> setings)
        w = buildString { for (c in w) if (isEmpty() || c != last() || isVowel(c)) append(c) }

        val sb = StringBuilder()
        var i = 0
        while (i < w.length) {
            val c = w[i]
            val start = i == 0
            val end = i == w.length - 1

            val rule = RULES.firstOrNull { w.startsWith(it.first, i) }
            if (rule != null) {
                if (start && isVowel(rule.first[0])) sb.append("ا")
                sb.append(rule.second)
                i += rule.first.length
                continue
            }
            val next = if (i + 1 < w.length) w[i + 1] else ' '
            when {
                c == 'c' -> sb.append(if (next in "eiy") "س" else "ک")
                c == 'g' -> sb.append(if (next in "eiy" && !start) "ج" else "گ")
                c == 'y' -> sb.append(if (start) "ی" else "ی")
                isVowel(c) -> sb.append(vowel(c, start, end))
                else -> sb.append(CONSONANTS[c] ?: "")
            }
            i++
        }
        return sb.toString()
    }

    private fun vowel(c: Char, start: Boolean, end: Boolean): String = when (c) {
        'a' -> if (start) "ا" else "ا"
        'e' -> if (start) "ای" else if (end) "ی" else "ی"
        'i' -> if (start) "ا" else "ی"
        'o' -> if (start) "او" else "و"
        'u' -> if (start) "ا" else if (end) "و" else ""
        else -> ""
    }
}
