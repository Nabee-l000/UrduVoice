package com.urduvoice.tts

import android.content.Context
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Real English voice (Piper / LJSpeech, public domain) running offline through sherpa-onnx.
 * Files live in assets/english/: en.onnx, tokens.txt, espeak-ng-data/
 */
class EnglishEngine private constructor(ctx: Context) {

    companion object {
        private const val DIR = "english"
        private const val CACHE_MAX_CHARS = 40
        @Volatile private var instance: EnglishEngine? = null

        /** True if the English voice was included in this build. */
        fun available(ctx: Context): Boolean =
            try { ctx.assets.list(DIR)?.contains("en.onnx") == true } catch (e: Exception) { false }

        fun get(ctx: Context): EnglishEngine =
            instance ?: synchronized(this) {
                instance ?: EnglishEngine(ctx.applicationContext).also { instance = it }
            }

        /** Make English letters/punctuation only (emoji and other symbols removed). */
        fun clean(text: String): String =
            text.replace(Regex("""[^\x20-\x7E’]"""), " ").replace(Regex("""\s+"""), " ").trim()
    }

    private val tts: OfflineTts
    private val sampleRate: Int

    private val cache = object : LinkedHashMap<String, ByteArray>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?) = size > 200
    }

    init {
        val root = copyAssetDir(ctx, DIR)
        val vits = OfflineTtsVitsModelConfig(
            model = File(root, "en.onnx").absolutePath,
            tokens = File(root, "tokens.txt").absolutePath,
            dataDir = File(root, "espeak-ng-data").absolutePath
        )
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(vits = vits, numThreads = threads, debug = false, provider = "cpu")
        )
        tts = OfflineTts(null, config)
        sampleRate = tts.sampleRate()
    }

    /** English text -> PCM16 at the app's sample rate. */
    @Synchronized
    fun speakPcm(text: String, speed: Float): ByteArray {
        val t = clean(text)
        if (t.isEmpty()) return ByteArray(0)
        val key = "${(speed * 100).roundToInt()}|$t"
        if (t.length <= CACHE_MAX_CHARS) cache[key]?.let { return it }
        val audio = tts.generate(t, 0, speed)
        var wav = audio.samples
        if (audio.sampleRate != UrduTtsEngine.SAMPLE_RATE) wav = resample(wav, audio.sampleRate, UrduTtsEngine.SAMPLE_RATE)
        wav = matchLoudness(trimSilence(wav))
        val pcm = UrduTtsEngine.toPcm16(wav)
        if (t.length <= CACHE_MAX_CHARS) cache[key] = pcm
        return pcm
    }

    /** Cut long silences at the start/end so the voice switch feels seamless. */
    private fun trimSilence(x: FloatArray): FloatArray {
        val th = 0.01f
        val keep = UrduTtsEngine.SAMPLE_RATE / 20 // keep 50 ms
        var s = 0
        while (s < x.size && abs(x[s]) < th) s++
        var e = x.size - 1
        while (e > s && abs(x[e]) < th) e--
        if (s >= e) return x
        return x.copyOfRange((s - keep).coerceAtLeast(0), (e + keep).coerceAtMost(x.size))
    }

    /** Bring English to roughly the same loudness as the Urdu voice. */
    private fun matchLoudness(x: FloatArray): FloatArray {
        var peak = 0f
        for (v in x) peak = maxOf(peak, abs(v))
        if (peak < 1e-4f) return x
        val gain = (0.85f / peak).coerceIn(0.5f, 3f)
        return FloatArray(x.size) { x[it] * gain }
    }

    private fun resample(x: FloatArray, from: Int, to: Int): FloatArray {
        val ratio = from.toDouble() / to
        val n = (x.size / ratio).toInt()
        val last = x.size - 1
        return FloatArray(n) { i ->
            val p = i * ratio
            val i0 = p.toInt().coerceAtMost(last)
            val i1 = (i0 + 1).coerceAtMost(last)
            val f = (p - i0).toFloat()
            x[i0] + (x[i1] - x[i0]) * f
        }
    }

    /** sherpa-onnx needs real files: copy the assets/english folder once per app install/update. */
    private fun copyAssetDir(ctx: Context, dir: String): File {
        val root = File(ctx.filesDir, dir)
        val stamp = File(root, ".installed")
        val installed = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        if (stamp.exists() && stamp.readText() == installed.toString()) return root
        root.deleteRecursively()
        copyRecursive(ctx, dir, root)
        stamp.writeText(installed.toString())
        return root
    }

    private fun copyRecursive(ctx: Context, assetPath: String, dest: File) {
        val children = ctx.assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            ctx.assets.open(assetPath).use { input -> dest.outputStream().use { input.copyTo(it, 1 shl 16) } }
        } else {
            dest.mkdirs()
            for (c in children) copyRecursive(ctx, "$assetPath/$c", File(dest, c))
        }
    }
}
