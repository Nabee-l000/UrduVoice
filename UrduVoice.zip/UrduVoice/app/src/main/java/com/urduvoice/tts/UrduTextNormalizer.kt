package com.urduvoice.tts

/**
 * Turns raw screen text into something the Urdu model can read:
 * numbers -> Urdu words, common symbols -> words, sentence splitting.
 * The model only knows Urdu letters; anything else is skipped (read as a pause).
 */
object UrduTextNormalizer {

    private val ONES = arrayOf(
        "صفر", "ایک", "دو", "تین", "چار", "پانچ", "چھ", "سات", "آٹھ", "نو",
        "دس", "گیارہ", "بارہ", "تیرہ", "چودہ", "پندرہ", "سولہ", "سترہ", "اٹھارہ", "انیس",
        "بیس", "اکیس", "بائیس", "تئیس", "چوبیس", "پچیس", "چھبیس", "ستائیس", "اٹھائیس", "انتیس",
        "تیس", "اکتیس", "بتیس", "تینتیس", "چونتیس", "پینتیس", "چھتیس", "سینتیس", "اڑتیس", "انتالیس",
        "چالیس", "اکتالیس", "بیالیس", "تینتالیس", "چوالیس", "پینتالیس", "چھیالیس", "سینتالیس", "اڑتالیس", "انچاس",
        "پچاس", "اکاون", "باون", "ترپن", "چون", "پچپن", "چھپن", "ستاون", "اٹھاون", "انسٹھ",
        "ساٹھ", "اکسٹھ", "باسٹھ", "تریسٹھ", "چونسٹھ", "پینسٹھ", "چھیاسٹھ", "سڑسٹھ", "اڑسٹھ", "انہتر",
        "ستر", "اکہتر", "بہتر", "تہتر", "چوہتر", "پچھتر", "چھہتر", "ستتر", "اٹھہتر", "اناسی",
        "اسی", "اکاسی", "بیاسی", "تراسی", "چوراسی", "پچاسی", "چھیاسی", "ستاسی", "اٹھاسی", "نواسی",
        "نوے", "اکانوے", "بانوے", "ترانوے", "چورانوے", "پچانوے", "چھیانوے", "ستانوے", "اٹھانوے", "ننانوے"
    )

    private val MONTHS = arrayOf(
        "جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
        "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"
    )

    private val SYMBOLS = mapOf(
        "%" to " فیصد ",
        "&" to " اور ",
        "+" to " جمع ",
        "=" to " برابر ",
        "@" to " ایٹ ",
        "#" to " ہیش ",
        "₨" to " روپے "
    )

    private val EMOJI = mapOf(
        "😂" to "ہنسی", "🤣" to "زوردار ہنسی", "😅" to "شرمندہ ہنسی", "😆" to "ہنسی", "😄" to "مسکراہٹ",
        "😀" to "مسکراہٹ", "😁" to "مسکراہٹ", "😊" to "مسکراہٹ", "🙂" to "ہلکی مسکراہٹ", "😉" to "آنکھ مارنا",
        "😍" to "پیار", "🥰" to "پیار", "😘" to "بوسہ", "❤" to "دل", "♥" to "دل", "💕" to "دل", "💖" to "دل",
        "💔" to "ٹوٹا دل", "😢" to "آنسو", "😭" to "رونا", "😡" to "غصہ", "😠" to "غصہ", "😮" to "حیرت",
        "😱" to "ڈر", "🤔" to "سوچ", "😴" to "نیند", "😎" to "کول", "🤗" to "گلے ملنا", "👍" to "پسند",
        "👎" to "ناپسند", "👏" to "تالیاں", "🙏" to "ہاتھ جوڑے", "🤲" to "دعا", "👋" to "سلام",
        "🔥" to "آگ", "🎉" to "مبارکباد", "🎂" to "سالگرہ", "🌹" to "گلاب", "💐" to "گلدستہ",
        "✅" to "ٹھیک", "✔" to "ٹھیک", "❌" to "غلط", "⚠" to "خبردار", "📞" to "فون", "📷" to "کیمرہ",
        "🕌" to "مسجد", "🌙" to "چاند", "☀" to "سورج", "⭐" to "ستارہ", "💯" to "سو فیصد", "💪" to "طاقت",
        "😔" to "اداس", "🥺" to "التجا", "😇" to "معصوم", "🤝" to "ہاتھ ملانا"
    )

    private val NUMBER = Regex("""\d+(?:[.,]\d+)*""")
    private val DATE = Regex("""\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4}|\d{2})\b""")
    private val TIME = Regex("""\b([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?(?:\s*([AaPp])\.?[Mm]\.?)?""")
    private val MONEY = Regex("""(?i)(?:\bRs\.?|\bPKR|₨)\s*(\d[\d,]*(?:\.\d+)?)""")
    private val DOLLAR = Regex("""\$\s*(\d[\d,]*(?:\.\d+)?)""")
    // Split after ۔ ؟ ! ? newline, and after "." only when a space/end follows (so 3.5 stays whole)
    private val SENTENCE_END = Regex("""(?<=[۔؟!?\n])|(?<=\.)(?=\s|$)""")

    /** Split long text so the first sentence is spoken while the rest is generated. */
    fun splitSentences(text: String): List<String> =
        text.split(SENTENCE_END).map { it.trim() }.filter { it.isNotEmpty() }

    // Long sentences are cut at commas/colons so speech starts sooner
    private val CLAUSE_END = Regex("""(?<=[،,;:؛])""")
    private const val CLAUSE_MIN = 25

    /** Sentences, with long ones split into clauses. First chunk = fastest start. */
    fun splitForSpeech(text: String): List<String> {
        val out = mutableListOf<String>()
        for (sentence in splitSentences(text)) {
            if (sentence.length <= CLAUSE_MIN * 2) { out += sentence; continue }
            var buf = ""
            for (part in sentence.split(CLAUSE_END)) {
                buf += part
                if (buf.trim().length >= CLAUSE_MIN) { out += buf.trim(); buf = "" }
            }
            if (buf.isNotBlank()) {
                if (out.isNotEmpty() && buf.trim().length < 10) out[out.size - 1] = out.last() + " " + buf.trim()
                else out += buf.trim()
            }
        }
        return out
    }

    private val RUPEES = Regex("""(?i)\bRs\.?(?=\s|\d|$)""")
    // Anything that is not Urdu/Arabic script or a pause mark is dropped (emoji, Chinese, symbols)
    private val NOT_URDU = Regex("""[^؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿\s]""")

    fun normalize(input: String, userDict: Map<String, String> = emptyMap()): String {
        var s = applyUserDict(input, userDict)
        s = replaceEmoji(s)
        s = toAsciiDigits(s)
        s = DATE.replace(s) { m ->
            " " + dateWords(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3], m.value) + " "
        }
        s = TIME.replace(s) { m ->
            " " + timeWords(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3]) + " "
        }
        s = MONEY.replace(s) { m -> " " + numberToWords(m.groupValues[1]) + " روپے " }
        s = DOLLAR.replace(s) { m -> " " + numberToWords(m.groupValues[1]) + " ڈالر " }
        s = RUPEES.replace(s, " روپے ")
        for ((k, v) in SYMBOLS) s = s.replace(k, v)
        s = NUMBER.replace(s) { m -> " " + numberToWords(m.value) + " " }
        s = EnglishToUrdu.convert(s)
        // Urdu-style punctuation the model understands as pauses
        s = s.replace(',', '،').replace('?', '؟').replace('.', '۔').replace(';', '،').replace(':', '،')
        s = NOT_URDU.replace(s, " ")
        s = s.replace(Regex("""بجے(\s+بجے)+"""), "بجے")   // "1:30 بجے" -> no double بجے
        return s.replace(Regex("""\s+"""), " ").trim()
    }

    private fun applyUserDict(s: String, dict: Map<String, String>): String {
        var r = s
        for ((k, v) in dict) {
            if (k.isBlank()) continue
            r = if (k.any { it in 'A'..'Z' || it in 'a'..'z' }) {
                Regex("(?i)(?<![A-Za-z])" + Regex.escape(k) + "(?![A-Za-z])")
                    .replace(r, " " + Regex.escapeReplacement(v) + " ")
            } else {
                r.replace(k, v)
            }
        }
        return r
    }

    private fun replaceEmoji(s: String): String {
        val clean = s.replace("️", "").replace("‍", "")
        val sb = StringBuilder(clean.length)
        var last: String? = null
        var i = 0
        while (i < clean.length) {
            val cp = clean.codePointAt(i)
            val w = EMOJI[String(Character.toChars(cp))]
            if (w != null) {
                if (w != last) sb.append(' ').append(w).append(' ')   // 😂😂😂 -> one "ہنسی"
                last = w
            } else {
                if (!Character.isWhitespace(cp)) last = null
                sb.appendCodePoint(cp)
            }
            i += Character.charCount(cp)
        }
        return sb.toString()
    }

    /** 23/11/2026 -> تئیس نومبر دو ہزار چھبیس (day/month/year, as used in Pakistan) */
    private fun dateWords(d: Int, m: Int, yRaw: String, original: String): String {
        if (d !in 1..31 || m !in 1..12) return original.replace('/', ' ').replace('-', ' ')
        val y = if (yRaw.length == 2) 2000 + yRaw.toInt() else yRaw.toInt()
        val year = if (y in 1100..1999) {
            words((y / 100).toLong()) + " سو" + (if (y % 100 > 0) " " + words((y % 100).toLong()) else "")
        } else words(y.toLong())
        return "${words(d.toLong())} ${MONTHS[m - 1]} $year"
    }

    /** 10:30 -> ساڑھے دس بجے, 4:15 pm -> شام سوا چار بجے */
    private fun timeWords(h24: Int, m: Int, ampm: String): String {
        val pm = ampm.equals("p", true) || (ampm.isEmpty() && h24 >= 13)
        val am = ampm.equals("a", true)
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val prefix = when {
            am -> "صبح "
            pm -> when (h12) { 12, 1, 2, 3 -> "دوپہر "; 4, 5, 6 -> "شام "; else -> "رات " }
            ampm.isEmpty() && h24 == 0 -> "رات "
            else -> ""
        }
        val next = h12 % 12 + 1
        val core = when (m) {
            0 -> "${words(h12.toLong())} بجے"
            15 -> "سوا ${words(h12.toLong())} بجے"
            30 -> when (h12) {
                1 -> "ڈیڑھ بجے"
                2 -> "ڈھائی بجے"
                else -> "ساڑھے ${words(h12.toLong())} بجے"
            }
            45 -> "پونے ${words(next.toLong())} بجے"
            else -> "${words(h12.toLong())} بج کر ${words(m.toLong())} منٹ"
        }
        return prefix + core
    }

    private fun toAsciiDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when (c) {
                    in '۰'..'۹' -> '0' + (c - '۰')   // Urdu/Persian digits
                    in '٠'..'٩' -> '0' + (c - '٠')   // Arabic digits
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    private fun numberToWords(raw: String): String {
        // 1,234,567 -> 1234567 ; 3.5 -> "تین اعشاریہ پانچ"
        val cleaned = raw.replace(",", "")
        val parts = cleaned.split('.')
        if (parts.size == 2 && parts[0].isNotEmpty() && parts[1].isNotEmpty()) {
            return intWords(parts[0]) + " اعشاریہ " + digitByDigit(parts[1])
        }
        return parts.joinToString(" ") { intWords(it) }
    }

    private fun intWords(digits: String): String {
        if (digits.isEmpty()) return ""
        // Phone numbers, codes, very long numbers: read digit by digit
        if (digits.length > 9 || (digits.length > 1 && digits.startsWith("0"))) return digitByDigit(digits)
        return words(digits.toLong())
    }

    private fun digitByDigit(d: String) = d.map { ONES[it - '0'] }.joinToString(" ")

    fun words(n: Long): String {
        if (n < 100) return ONES[n.toInt()]
        val out = mutableListOf<String>()
        var r = n
        if (r >= 10_000_000) { out += words(r / 10_000_000) + " کروڑ"; r %= 10_000_000 }
        if (r >= 100_000) { out += ONES[(r / 100_000).toInt()] + " لاکھ"; r %= 100_000 }
        if (r >= 1_000) { out += ONES[(r / 1_000).toInt()] + " ہزار"; r %= 1_000 }
        if (r >= 100) { out += ONES[(r / 100).toInt()] + " سو"; r %= 100 }
        if (r > 0) out += ONES[r.toInt()]
        return out.joinToString(" ")
    }
}
