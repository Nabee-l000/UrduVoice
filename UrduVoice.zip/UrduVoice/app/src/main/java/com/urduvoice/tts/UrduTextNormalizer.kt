package com.urduvoice.tts

/**
 * Turns raw screen text into something the Urdu model can read:
 * numbers -> Urdu words, common symbols -> words, sentence splitting.
 * The model only knows Urdu letters; anything else is skipped (read as a pause).
 */
object UrduTextNormalizer {

    private val ONES = arrayOf(
        "صفر", "ایک", "دو", "تین", "چار", "پانچ", "چھ", "سات", "آٹھ", "نو",
        "دس", "گیارہ", "بارہ", "تیرہ", "چودہ", "پندرہ", "سولہ", "سترہ", "اٹھارہ", "انیس",
        "بیس", "اکیس", "بائیس", "تئیس", "چوبیس", "پچیس", "چھبیس", "ستائیس", "اٹھائیس", "انتیس",
        "تیس", "اکتیس", "بتیس", "تینتیس", "چونتیس", "پینتیس", "چھتیس", "سینتیس", "اڑتیس", "انتالیس",
        "چالیس", "اکتالیس", "بیالیس", "تینتالیس", "چوالیس", "پینتالیس", "چھیالیس", "سینتالیس", "اڑتالیس", "انچاس",
        "پچاس", "اکاون", "باون", "ترپن", "چون", "پچپن", "چھپن", "ستاون", "اٹھاون", "انسٹھ",
        "ساٹھ", "اکسٹھ", "باسٹھ", "تریسٹھ", "چونسٹھ", "پینسٹھ", "چھیاسٹھ", "سڑسٹھ", "اڑسٹھ", "انہتر",
        "ستر", "اکہتر", "بہتر", "تہتر", "چوہتر", "پچھتر", "چھہتر", "ستتر", "اٹھہتر", "اناسی",
        "اسی", "اکاسی", "بیاسی", "تراسی", "چوراسی", "پچاسی", "چھیاسی", "ستاسی", "اٹھاسی", "نواسی",
        "نوے", "اکانوے", "بانوے", "ترانوے", "چورانوے", "پچانوے", "چھیانوے", "ستانوے", "اٹھانوے", "ننانوے"
    )

    private val SYMBOLS = mapOf(
        "%" to " فیصد ",
        "&" to " اور ",
        "+" to " جمع ",
        "=" to " برابر ",
        "@" to " ایٹ ",
        "Rs." to " روپے ",
        "Rs" to " روپے ",
        "₨" to " روپے "
    )

    private val NUMBER = Regex("""\d+(?:[.,]\d+)*""")
    // Split after ۔ ؟ ! ? newline, and after "." only when a space/end follows (so 3.5 stays whole)
    private val SENTENCE_END = Regex("""(?<=[۔؟!?\n])|(?<=\.)(?=\s|$)""")

    /** Split long text so the first sentence is spoken while the rest is generated. */
    fun splitSentences(text: String): List<String> =
        text.split(SENTENCE_END).map { it.trim() }.filter { it.isNotEmpty() }

    fun normalize(input: String): String {
        var s = toAsciiDigits(input)
        for ((k, v) in SYMBOLS) s = s.replace(k, v)
        s = NUMBER.replace(s) { m -> " " + numberToWords(m.value) + " " }
        // Urdu-style punctuation the model understands as pauses
        s = s.replace(',', '،').replace('?', '؟')
        return s.replace(Regex("""\s+"""), " ").trim()
    }

    private fun toAsciiDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when (c) {
                    in '۰'..'۹' -> '0' + (c - '۰')   // Urdu/Persian digits
                    in '٠'..'٩' -> '0' + (c - '٠')   // Arabic digits
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    private fun numberToWords(raw: String): String {
        // 1,234,567 -> 1234567 ; 3.5 -> "تین اعشاریہ پانچ"
        val cleaned = raw.replace(",", "")
        val parts = cleaned.split('.')
        if (parts.size == 2 && parts[0].isNotEmpty() && parts[1].isNotEmpty()) {
            return intWords(parts[0]) + " اعشاریہ " + digitByDigit(parts[1])
        }
        return parts.joinToString(" ") { intWords(it) }
    }

    private fun intWords(digits: String): String {
        if (digits.isEmpty()) return ""
        // Phone numbers, codes, very long numbers: read digit by digit
        if (digits.length > 9 || (digits.length > 1 && digits.startsWith("0"))) return digitByDigit(digits)
        return words(digits.toLong())
    }

    private fun digitByDigit(d: String) = d.map { ONES[it - '0'] }.joinToString(" ")

    fun words(n: Long): String {
        if (n < 100) return ONES[n.toInt()]
        val out = mutableListOf<String>()
        var r = n
        if (r >= 10_000_000) { out += words(r / 10_000_000) + " کروڑ"; r %= 10_000_000 }
        if (r >= 100_000) { out += ONES[(r / 100_000).toInt()] + " لاکھ"; r %= 100_000 }
        if (r >= 1_000) { out += ONES[(r / 1_000).toInt()] + " ہزار"; r %= 1_000 }
        if (r >= 100) { out += ONES[(r / 100).toInt()] + " سو"; r %= 100 }
        if (r > 0) out += ONES[r.toInt()]
        return out.joinToString(" ")
    }
}
