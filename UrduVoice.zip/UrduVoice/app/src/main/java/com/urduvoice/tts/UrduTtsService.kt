package com.urduvoice.tts

import android.media.AudioFormat
import android.speech.tts.SynthesisCallback
import android.speech.tts.SynthesisRequest
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeechService
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale
import kotlin.math.min

/** System TTS engine: lets TalkBack, WhatsApp, e-readers etc. speak with this Urdu voice. */
class UrduTtsService : TextToSpeechService() {

    companion object {
        private const val TAG = "UrduTtsService"
        private val LOCALE = Locale("ur", "PK")

        /** Phrases TalkBack says constantly — generated in advance so they play instantly. */
        val COMMON_PHRASES = listOf(
            "بٹن", "ڈبل ٹیپ کریں", "فعال کرنے کے لیے ڈبل ٹیپ کریں", "منتخب شدہ", "غیر منتخب",
            "واپس", "ہوم", "ہوم اسکرین", "اطلاع", "اطلاعات", "پیغام", "نیا پیغام", "کال", "تلاش کریں",
            "مزید اختیارات", "بند کریں", "کھولیں", "آن", "آف", "ٹیب", "فہرست", "صفحہ",
            "WhatsApp", "Settings", "Battery", "Wi-Fi", "Bluetooth", "Chrome", "YouTube", "Camera",
            "Gallery", "Phone", "Messages", "Google", "OK", "Cancel", "Back", "Home", "Search"
        )
    }

    @Volatile private var stopRequested = false

    override fun onCreate() {
        super.onCreate()
        // Load models + prepare common phrases in the background so the first words are fast
        Thread {
            try {
                val engine = UrduTtsEngine.get(this)
                engine.prewarm(COMMON_PHRASES, AppPrefs.lastSpeed(this), AppPrefs.voice(this), AppPrefs.userDict(this))
            } catch (e: Throwable) {
                Log.e(TAG, "Model load failed", e)
            }
        }.apply { priority = Thread.MIN_PRIORITY }.start()
    }

    private fun isUrdu(lang: String?) = lang != null && (lang.equals("urd", true) || lang.equals("ur", true))

    override fun onIsLanguageAvailable(lang: String?, country: String?, variant: String?): Int = when {
        !isUrdu(lang) -> TextToSpeech.LANG_NOT_SUPPORTED
        country.equals("PAK", true) || country.equals("PK", true) -> TextToSpeech.LANG_COUNTRY_AVAILABLE
        else -> TextToSpeech.LANG_AVAILABLE
    }

    override fun onGetLanguage(): Array<String> = arrayOf("urd", "PAK", "")

    override fun onLoadLanguage(lang: String?, country: String?, variant: String?): Int =
        onIsLanguageAvailable(lang, country, variant)

    override fun onStop() {
        stopRequested = true
        UrduTtsEngine.peek()?.cancel()
    }

    override fun onGetVoices(): MutableList<Voice> =
        VoicePresets.ALL.map {
            Voice(it.id, LOCALE, Voice.QUALITY_HIGH, Voice.LATENCY_NORMAL, false, emptySet())
        }.toMutableList()

    override fun onIsValidVoiceName(voiceName: String?): Int =
        if (VoicePresets.ALL.any { it.id == voiceName }) TextToSpeech.SUCCESS else TextToSpeech.ERROR

    override fun onLoadVoice(voiceName: String?): Int = onIsValidVoiceName(voiceName)

    override fun onGetDefaultVoiceNameFor(lang: String?, country: String?, variant: String?): String? =
        if (isUrdu(lang)) AppPrefs.voice(this).id else null

    override fun onSynthesizeText(request: SynthesisRequest, callback: SynthesisCallback) {
        stopRequested = false
        val text = request.charSequenceText?.toString().orEmpty()

        val engine = try {
            UrduTtsEngine.get(this)
        } catch (e: Throwable) {
            Log.e(TAG, "Engine unavailable", e)
            callback.error()
            return
        }
        engine.resetCancel()

        // Android speech rate: 100 = normal. TalkBack users often go 2-3x.
        val speed = (request.speechRate / 100f).coerceIn(0.3f, 4f)
        AppPrefs.setLastSpeed(this, speed)
        // The style picked in the app is used everywhere (TalkBack doesn't offer a voice picker)
        val preset = AppPrefs.voice(this)
        val dict = AppPrefs.userDict(this)

        callback.start(UrduTtsEngine.SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1)
        try {
            for (chunk in UrduTextNormalizer.splitForSpeech(text)) {
                if (stopRequested) break
                val norm = UrduTextNormalizer.normalize(chunk, dict)
                if (norm.isBlank()) continue
                val pcm = engine.speakPcm(norm, speed, preset)
                val max = callback.maxBufferSize
                var off = 0
                while (off < pcm.size && !stopRequested) {
                    val n = min(max, pcm.size - off)
                    callback.audioAvailable(pcm, off, n)
                    off += n
                }
            }
        } catch (e: UrduTtsEngine.Cancelled) {
            // TalkBack moved on — not an error
        } catch (e: Throwable) {
            Log.e(TAG, "Synthesis failed", e)
            callback.error()
            return
        }
        callback.done()
    }
}
