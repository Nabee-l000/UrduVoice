package com.urduvoice.tts

import android.media.AudioFormat
import android.speech.tts.SynthesisCallback
import android.speech.tts.SynthesisRequest
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeechService
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale
import kotlin.math.min

/** System TTS engine: lets TalkBack, WhatsApp, e-readers etc. speak with this Urdu voice. */
class UrduTtsService : TextToSpeechService() {

    companion object {
        private const val TAG = "UrduTtsService"
        const val VOICE_NAME = "ur-PK-matcha-1"
        private val LOCALE = Locale("ur", "PK")
    }

    @Volatile private var stopRequested = false

    override fun onCreate() {
        super.onCreate()
        // Load models in the background so the first utterance is fast
        Thread {
            try { UrduTtsEngine.get(this) } catch (e: Throwable) { Log.e(TAG, "Model load failed", e) }
        }.start()
    }

    private fun isUrdu(lang: String?) = lang != null && (lang.equals("urd", true) || lang.equals("ur", true))

    override fun onIsLanguageAvailable(lang: String?, country: String?, variant: String?): Int = when {
        !isUrdu(lang) -> TextToSpeech.LANG_NOT_SUPPORTED
        country.equals("PAK", true) || country.equals("PK", true) -> TextToSpeech.LANG_COUNTRY_AVAILABLE
        else -> TextToSpeech.LANG_AVAILABLE
    }

    override fun onGetLanguage(): Array<String> = arrayOf("urd", "PAK", "")

    override fun onLoadLanguage(lang: String?, country: String?, variant: String?): Int =
        onIsLanguageAvailable(lang, country, variant)

    override fun onStop() { stopRequested = true }

    override fun onGetVoices(): MutableList<Voice> = mutableListOf(
        Voice(VOICE_NAME, LOCALE, Voice.QUALITY_HIGH, Voice.LATENCY_NORMAL, false, emptySet())
    )

    override fun onIsValidVoiceName(voiceName: String?): Int =
        if (voiceName == VOICE_NAME) TextToSpeech.SUCCESS else TextToSpeech.ERROR

    override fun onLoadVoice(voiceName: String?): Int = onIsValidVoiceName(voiceName)

    override fun onGetDefaultVoiceNameFor(lang: String?, country: String?, variant: String?): String? =
        if (isUrdu(lang)) VOICE_NAME else null

    override fun onSynthesizeText(request: SynthesisRequest, callback: SynthesisCallback) {
        stopRequested = false
        val text = request.charSequenceText?.toString().orEmpty()

        val engine = try {
            UrduTtsEngine.get(this)
        } catch (e: Throwable) {
            Log.e(TAG, "Engine unavailable", e)
            callback.error()
            return
        }

        // Android speech rate: 100 = normal. TalkBack users often go 2-3x.
        val speed = (request.speechRate / 100f).coerceIn(0.3f, 4f)

        callback.start(UrduTtsEngine.SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1)
        try {
            for (sentence in UrduTextNormalizer.splitForSpeech(text)) {
                if (stopRequested) break
                val norm = UrduTextNormalizer.normalize(sentence)
                if (norm.isBlank()) continue
                val pcm = UrduTtsEngine.toPcm16(engine.synthesize(norm, speed))
                val max = callback.maxBufferSize
                var off = 0
                while (off < pcm.size && !stopRequested) {
                    val n = min(max, pcm.size - off)
                    callback.audioAvailable(pcm, off, n)
                    off += n
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Synthesis failed", e)
            callback.error()
            return
        }
        callback.done()
    }
}
