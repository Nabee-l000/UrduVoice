plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.urduvoice.tts"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.urduvoice.tts"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
        // 64-bit phones only (all phones from the last ~6 years): ~12 MB smaller
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Test builds are signed with the debug key so they install directly.
            // Use your own release key before publishing on Play Store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // Models are stored compressed in the APK (smaller download) and unpacked once on first launch
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
}
