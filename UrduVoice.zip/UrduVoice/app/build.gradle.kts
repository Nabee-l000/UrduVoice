plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.urduvoice.tts"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.urduvoice.tts"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        // Only real-phone CPUs: keeps the APK smaller
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Test builds are signed with the debug key so they install directly.
            // Use your own release key before publishing on Play Store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // Keep models uncompressed so they copy/load fast
    androidResources { noCompress += listOf("onnx") }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
}
