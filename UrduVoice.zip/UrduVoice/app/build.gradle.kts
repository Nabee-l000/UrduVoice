plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.urduvoice.tts"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.urduvoice.tts"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
        // 64-bit phones only (all phones from the last ~6 years): ~12 MB smaller
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Test builds are signed with the debug key so they install directly.
            // Use your own release key before publishing on Play Store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    // Models are stored compressed in the APK (smaller download) and unpacked once on first launch
    // The English engine (sherpa-onnx) and our Urdu engine share one ONNX Runtime.
    // Versions are matched in build.yml, so keeping either copy is safe.
    packaging {
        jniLibs { pickFirsts += listOf("**/libonnxruntime.so") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Must equal the ONNX Runtime version inside the sherpa-onnx library (build.yml detects it)
val ortVersion = (project.findProperty("ortVersion") as String?) ?: "1.27.1"

dependencies {
    implementation("com.microsoft.onnxruntime:onnxruntime-android:$ortVersion")
    // English voice engine, downloaded by build.yml into app/libs/
    implementation(files("libs/sherpa-onnx.aar"))
}
