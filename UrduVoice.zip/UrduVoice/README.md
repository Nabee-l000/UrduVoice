# Urdu Voice — offline Urdu TTS engine for Android

Matcha-TTS (Urdu) + Vocos vocoder running on-device with ONNX Runtime.
Works as a system text-to-speech engine, so TalkBack, WhatsApp, e-readers and
any app using Android TTS can speak Urdu with it.

## Get the APK (no PC setup)
1. Create a new GitHub repository and upload all files from this folder
   (keep the folder structure, including `.github/workflows/build.yml`).
2. Put build.yml at .github/workflows/build.yml in the repo root. Open the **Actions** tab → **Build APK**. It runs automatically on every push to `main`
   (or press **Run workflow**). Takes ~5–8 minutes.
3. When it's green, open the run → **Artifacts** → download **UrduVoice-apk** (a zip with the APK).
4. Install the APK on your phone (allow "Install unknown apps").

## Use it
- Open **Urdu Voice** → type Urdu → **Speak**. The screen shows latency and RTF
  (RTF below ~0.3 feels instant for TalkBack).
- **Set as phone TTS voice** → Preferred engine → **Urdu Voice**.
- TalkBack: Settings → Text-to-speech uses the preferred engine.

## Project layout
- `UrduTtsEngine.kt` — loads models, text → audio
- `Istft.kt` — turns Vocos output into a waveform
- `UrduTextNormalizer.kt` — numbers/symbols → Urdu words, sentence splitting
- `UrduTtsService.kt` — the Android system TTS engine
- `MainActivity.kt` — test screen

## Notes
- Models are downloaded during the build (not stored in git):
  `AhsanTalal/urdu-matcha-tts` (Apache-2.0) and sherpa-onnx `vocos-22khz-univ.onnx`.
- Before selling: confirm the voice's training-data rights or train on your own voice actor,
  and sign the APK with your own release key.
- Only Urdu script is spoken; English words are skipped for now.
