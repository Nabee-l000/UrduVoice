# Urdu Voice — offline Urdu TTS engine for Android

Matcha-TTS (Urdu) + Vocos vocoder running on-device with ONNX Runtime.
Works as a system text-to-speech engine, so TalkBack, WhatsApp, e-readers and
any app using Android TTS can speak Urdu with it.

## Get the APK (no PC setup)
1. Create a new GitHub repository and upload all files from this folder
   (keep the folder structure, including `.github/workflows/build.yml`).
2. Put build.yml at .github/workflows/build.yml in the repo root. Open the **Actions** tab → **Build APK**. It runs automatically on every push to `main`
   (or press **Run workflow**). Takes ~5–8 minutes.
3. When it's green, open the run → **Artifacts** → download **UrduVoice-apk** (a zip with the APK).
4. Install the APK on your phone (allow "Install unknown apps").

## Use it
- Open **Urdu Voice** → type Urdu → **Speak**. The screen shows latency and RTF
  (RTF below ~0.3 feels instant for TalkBack).
- **Set as phone TTS voice** → Preferred engine → **Urdu Voice**.
- TalkBack: Settings → Text-to-speech uses the preferred engine.

## Project layout
- `UrduTtsEngine.kt` — loads models, text → audio
- `Istft.kt` — turns Vocos output into a waveform
- `UrduTextNormalizer.kt` — numbers/symbols → Urdu words, sentence splitting
- `UrduTtsService.kt` — the Android system TTS engine
- `MainActivity.kt` — test screen

## v0.3 features
- Voice styles: Standard, Deep, Bright, Calm, Lively, Newsreader (pick in the app; TalkBack uses it)
- Instant replay of common/recent phrases, speech starts after the first clause, Stop works mid-sentence
- Reads times (10:30 → ساڑھے دس بجے), dates (23/11/2026), money (Rs 500, $20), emoji, Roman Urdu
- Bigger English word list + your own pronunciation dictionary in the app
- Smaller APK: 64-bit only, compressed models. Set QUANTIZE: 'true' in build.yml for ~half model size

## v0.4: real English voice
- English phrases are spoken by a real English voice (Piper LJSpeech, public domain) via sherpa-onnx (Apache-2.0)
- 1-2 English words inside Urdu keep the Urdu voice (no voice jump). Setting in the app: Off / Phrases / Every word
- build.yml downloads sherpa-onnx + the voice and matches the ONNX Runtime version automatically

## Notes
- Models are downloaded during the build (not stored in git):
  `AhsanTalal/urdu-matcha-tts` (Apache-2.0) and sherpa-onnx `vocos-22khz-univ.onnx`.
- Before selling: confirm the voice's training-data rights or train on your own voice actor,
  and sign the APK with your own release key.
- English is read with Urdu letters (Pakistani accent). A real English voice is a planned add-on.
- Voice styles come from one recorded voice. New speakers need new recordings + training.
